﻿this is an example of how you could create a manifest file for an application

this specific application changes the default front-end active event, 
creates one active event, and copes one web part to disc
the application will install itself in the 
your-files/applications/hello-world-example directory